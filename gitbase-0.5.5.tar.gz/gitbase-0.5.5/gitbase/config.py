"""Config file for GitBase package"""
canUse: bool = False