"""
The 'ProxyFile' extension of the 'GitBase' module: Allows streaming of remote files stored in a GitHub repository. This is useful for working with large files or media, as it avoids the need for downloading the entire file before usage. Supports streaming of audio and video files directly from GitHub.

Consists of: 
* ProxyFile (class): A class designed to facilitate streaming files from a GitHub repository using GitHub's raw content API.
    - param: repo_owner (str): The owner of the GitHub repository.
    - param: repo_name (str): The name of the repository.
    - param: token (str): The GitHub authentication token for accessing private repositories.
    - param: branch (str, optional): The GitHub branch (default is 'main').

    Methods:
        - _get_file_url(path: str) -> str: Constructs the URL to access a file in a GitHub repository.
            - param: path (str): The file's path in the repository.
            - returns: str: The constructed GitHub API URL.

        - _fetch_file(path: str) -> bytes: Fetches the file's content from GitHub without downloading it, returning the content as bytes.
            - param: path (str): The file's path in the repository.
            - returns: bytes: The file content in base64-decoded bytes.

        - get_file(remote_path: str) -> io.BytesIO: Retrieves any file from GitHub as an in-memory stream.
            - param: remote_path (str): The path to the file in the GitHub repository.
            - returns: io.BytesIO: A `BytesIO` object containing the file data.

        - play_audio(remote_path: str) -> None: Streams and plays an audio file (WAV format) directly from GitHub without downloading.
            - param: remote_path (str): The path to the audio file in the repository.

        - play_video(remote_path: str) -> None: Streams and plays a video file (MP4 format) directly from GitHub without downloading.
            - param: remote_path (str): The path to the video file in the repository.
"""

import requests
import base64
import io
import tempfile
import wave
import pyaudio
import cv2
import numpy as np
from moviepy import VideoFileClip

class ProxyFile:
    """
    ProxyFile allows streaming of remote files stored in a GitHub repository
    without downloading them.
    """

    def __init__(self, repo_owner: str, repo_name: str, token: str, branch: str = 'main') -> None:
        self.repo_owner = repo_owner
        self.repo_name = repo_name
        self.token = token
        self.branch = branch
        self.headers = {
            "Authorization": f"token {self.token}",
            "Accept": "application/vnd.github.v3.raw"
        }

    def _get_file_url(self, path: str) -> str:
        """Constructs the GitHub API URL for a given file path."""
        return f"https://api.github.com/repos/{self.repo_owner}/{self.repo_name}/contents/{path}?ref={self.branch}"

    def _fetch_file(self, path: str) -> bytes:
        """Fetches a file's content as bytes from GitHub without downloading."""
        url = self._get_file_url(path)
        response = requests.get(url, headers=self.headers)
        if response.status_code == 200:
            return base64.b64decode(response.json()["content"])  # Decode base64 content
        else:
            raise Exception(f"Error fetching file: {response.status_code} - {response.text}")

    def get_file(self, remote_path: str) -> io.BytesIO:
        """
        Fetches any file from GitHub and returns it as an in-memory stream.

        Args:
            remote_path (str): The path to the file in the GitHub repo.

        Returns:
            io.BytesIO: The file as a stream.
        """
        file_bytes = self._fetch_file(remote_path)
        return io.BytesIO(file_bytes)

    def play_audio(self, remote_path: str) -> None:
        """
        Streams and plays an audio file (WAV format) from GitHub without downloading.

        Args:
            remote_path (str): Path to the audio file in the repository.
        """
        try:
            audio_stream = self.get_file(remote_path)
            wf = wave.open(audio_stream, 'rb')

            p = pyaudio.PyAudio()
            stream = p.open(format=p.get_format_from_width(wf.getsampwidth()),
                            channels=wf.getnchannels(),
                            rate=wf.getframerate(),
                            output=True)

            data = wf.readframes(1024)
            while data:
                stream.write(data)
                data = wf.readframes(1024)

            stream.stop_stream()
            stream.close()
            p.terminate()

            print(f"Audio played successfully from {remote_path}")

        except Exception as e:
            print(f"Error playing audio: {e}")

    def play_video(self, remote_path: str) -> None:
        """
        Streams and plays a video file (MP4 format) from GitHub without downloading.

        Args:
            remote_path (str): Path to the video file in the repository.
        """
        try:
            video_stream = self.get_file(remote_path)

            # Use a temporary file to store video data
            with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as temp_video:
                temp_video.write(video_stream.read())
                temp_video_path = temp_video.name  # Store the temp file path

            # Open and play the video
            cap = cv2.VideoCapture(temp_video_path)
            while cap.isOpened():
                ret, frame = cap.read()
                if not ret:
                    break
                cv2.imshow("Video Stream", frame)
                if cv2.waitKey(25) & 0xFF == ord("q"):
                    break

            cap.release()
            cv2.destroyAllWindows()

            print(f"Video played successfully from {remote_path}")

        except Exception as e:
            print(f"Error playing video: {e}")
